# Remeselnicky portal — Implementation Backlog

## Purpose
This file is the canonical implementation sequencing artifact for the locked product definition in `ROADMAP.md`.

- `ROADMAP.md` = source of truth for product/domain decisions D01–D30.
- `IMPLEMENTATION_BACKLOG.md` = source of truth for build sequencing and bounded implementation work R0–R4.
- A backlog ticket may refine implementation detail, but it may not silently weaken or contradict a locked Dxx rule.
- Any required product-rule change must be recorded explicitly back in `ROADMAP.md` before the implementation ticket proceeds.

## Status model
- `READY` — dependencies resolved; safe to implement.
- `ACTIVE` — current implementation ticket.
- `BLOCKED` — dependency or explicit product/technical decision is missing.
- `DONE` — acceptance criteria and required tests pass.
- `DEFERRED` — intentionally moved out of Web Alpha scope.

## Ticket contract
Every implementation ticket must contain:
1. Objective.
2. Scope / non-scope.
3. Dependencies.
4. Locked Dxx references.
5. Acceptance criteria.
6. Required negative/security tests where applicable.
7. Codex boundary: what Codex may decide vs what is already locked.

## Autonomous Codex operating model
The backlog is a machine-readable work graph, not a sequence of prompts for the human to copy into Codex. The intended execution model is one long-running root Codex orchestrator operating against this repository and the locked `ROADMAP.md`.

The root agent MUST:
- read `ROADMAP.md` and this backlog before implementation;
- select the next `READY` ticket automatically;
- change ticket state `READY → ACTIVE → DONE` as work progresses;
- decompose tickets further internally when useful without changing locked product semantics;
- delegate independent work to subagents and run safe work in parallel;
- use separate worktrees/branches for parallel changes when appropriate;
- integrate subagent results, resolve conflicts, run the required checks, and continue to the next eligible ticket;
- fix ordinary test, lint, type, CI, integration, and implementation failures autonomously;
- keep the repository buildable and the backlog/checkpoint current;
- continue through R0–R4 without asking the human to relay prompts between agents.

Tickets remain intentionally bounded because they provide dependency control, reviewability, recovery points, and clean parallelization boundaries. Bounded tickets do NOT imply human micro-management.

### Human gates
Codex should stop and ask for a human decision only when at least one of these conditions is true:
1. A requested implementation would contradict, weaken, or materially reinterpret a locked D01–D30 product/domain rule.
2. Two locked rules are materially inconsistent and no safe implementation satisfies both.
3. A new product decision is required that is not already covered by the locked specification.
4. A destructive or difficult-to-reverse production-data action is required, including destructive migration/data loss outside an already approved recovery plan.
5. A new external vendor, paid service, billing commitment, legal agreement, production credential/account, or materially new third-party data flow must be chosen or authorized.
6. A material security/privacy/legal policy decision is required beyond D23–D27, or an implementation would intentionally weaken a locked security/privacy boundary.
7. Real-user production launch, widening of the invitation cohort, or another explicit D30 go/no-go release decision is reached.
8. Required repository, infrastructure, account, secret, or organizational access is unavailable and cannot be provisioned by the agent.
9. A BLOCKER/CRITICAL issue cannot be resolved without changing scope or accepting material risk.

The following are NOT human gates when they stay inside the locked architecture and acceptance criteria: package/tool selection, code organization, refactoring, test implementation, fixing failed tests, CI configuration, reversible/non-destructive migrations, internal API shape, naming, formatting, performance tuning, ordinary dependency upgrades, worktree/branch management, and other reversible engineering choices. Record durable implementation choices in repository documentation/ADR when they materially affect future work.

## Execution rule
Prefer small, reviewable implementation units while allowing the orchestrator to execute many such units autonomously and in parallel. A ticket should normally change one cohesive subsystem or one vertical slice and leave the repository buildable/testable. The root agent owns decomposition, delegation, integration, verification, and progression to the next ticket until a human gate is reached.

---

# R0 — Foundation

## R0 exit condition
R0 is complete when the repository has reproducible dev/staging/prod foundations, PostgreSQL/PostGIS migrations, authenticated users, verified email/phone, admin MFA, deny-by-default server authorization primitives, private/public media storage with safe upload processing, queue/outbox infrastructure, audit/admin foundation, observability/backups baseline, analytics/privacy scaffolding, and automated test infrastructure sufficient for R1–R4 to build on without re-architecting those cross-cutting concerns.

Primary locked references: D01–D04, D07, D13, D16, D23–D30.

## R0 sequencing
1. Repository/workspace and configuration.
2. Database and migrations.
3. Authentication/session/admin MFA.
4. Authorization and domain command primitives.
5. Storage/media security.
6. Queue/outbox/notification foundation.
7. Audit/admin shell.
8. Observability/backups.
9. Analytics/privacy scaffolding.
10. Test harness and release baseline.

### R0-001 — Bootstrap TypeScript monorepo
Status: `ACTIVE`

**Objective**
Create the repository structure that will host web, API/backend, workers and shared packages without duplicating domain contracts.

**Scope**
- TypeScript monorepo/workspace.
- Initial apps/packages layout for web, backend/API, worker(s), shared domain/contracts and shared configuration.
- Root scripts for build, typecheck, lint and test.
- Lockfile committed.
- Minimal README with local bootstrap commands.

**Non-scope**
- No product features.
- No domain state machine implementation beyond empty package boundaries.
- No deployment-provider-specific complexity beyond what is needed to keep structure deployable.

**Dependencies**
- None.

**Locked references**
- D30: bounded Codex tasks; definition/build separation.
- D26: dependency lockfile, CI/security baseline.

**Acceptance criteria**
- Fresh clone installs reproducibly from lockfile.
- Root `typecheck`, `lint`, `test`, and `build` commands succeed on the skeleton.
- Web/backend/worker can import shared packages without circular dependency hacks.
- No production secret or environment-specific credential exists in repo.

**Required tests/checks**
- Clean-install CI smoke.
- Typecheck all workspaces.

**Codex boundary**
Codex may choose exact workspace tooling if compatible with the locked stack direction; it may not split business rules into separate unshared implementations for web/mobile/backend.

### R0-002 — Shared engineering configuration
Status: `READY`

**Objective**
Establish consistent compiler, linting, formatting, testing and import boundaries.

**Dependencies**
- R0-001.

**Locked references**
- D26 deployment/CI security.
- D30 automated release gates.

**Acceptance criteria**
- Shared TypeScript config.
- Lint/format policy.
- Unit/integration test runner configured.
- Import-boundary rules prevent UI packages from becoming the source of domain authority.
- CI can execute all checks non-interactively.

### R0-003 — Typed environment/configuration layer
Status: `READY`

**Objective**
Create a validated configuration boundary for dev/staging/prod.

**Dependencies**
- R0-001.

**Locked references**
- D26 secrets/environment separation.
- D29 environment tagging.
- D30 staging/production separation.

**Acceptance criteria**
- Required env vars validated at startup.
- Dev/staging/prod config clearly separated.
- Secrets never reach client bundle unless explicitly public.
- Unsafe/missing production configuration fails fast.
- Environment name and release revision available to observability.

**Negative tests**
- Production startup fails when a required secret is absent.
- Server-only secret cannot be imported into browser bundle.

### R0-004 — CI baseline
Status: `READY`

**Objective**
Make every pull request run deterministic quality/security checks.

**Dependencies**
- R0-001, R0-002.

**Locked references**
- D26 CI/dependency/secret scanning.
- D30 release candidate gates.

**Acceptance criteria**
- Install from lockfile.
- Typecheck, lint, unit tests and build run in CI.
- Dependency vulnerability scan baseline.
- Secret scan baseline.
- CI fails on failed required checks.

### R0-005 — Deployment skeleton for dev/staging/prod
Status: `READY`

**Objective**
Provide reproducible environment deployments without coupling product logic to a hosting vendor.

**Dependencies**
- R0-003, R0-004.

**Locked references**
- D26 environment isolation/TLS.
- D29 deploy observability.
- D30 staging and release process.

**Acceptance criteria**
- Separate dev/staging/prod deployment configuration.
- Production TLS path defined.
- Release version/revision injected.
- Staging can be deployed from CI.
- Production deployment remains protected/manual-go-no-go capable.

### R0-006 — PostgreSQL + PostGIS foundation
Status: `READY`

**Objective**
Provision relational persistence and geo support from the beginning.

**Dependencies**
- R0-003.

**Locked references**
- D03 domain model.
- D07 PostGIS from start.
- D26 DB least privilege/environment separation.

**Acceptance criteria**
- PostgreSQL available in local/dev/staging.
- PostGIS extension enabled and migration-controlled.
- App uses parameterized ORM/query layer.
- DB connection config is server-only.
- Health diagnostics can distinguish DB unavailable vs app unavailable.

### R0-007 — Migration and database convention framework
Status: `READY`

**Objective**
Make schema evolution reviewable, reproducible and safe.

**Dependencies**
- R0-006.

**Locked references**
- D03 history/status model.
- D26 versioned migrations.
- D30 migration release gate.

**Acceptance criteria**
- Migration tooling committed.
- Server-generated timestamps conventions established.
- UUID/opaque ID convention established.
- Soft-delete/history-compatible conventions documented.
- Migration runs automatically on clean test DB.
- Roll-forward/rollback/recovery procedure documented at baseline level.

### R0-008 — Core identity/User persistence
Status: `READY`

**Objective**
Implement one User identity that can later own CustomerProfile and/or CraftsmanProfile.

**Dependencies**
- R0-006, R0-007.

**Locked references**
- D02 one User with optional profiles.
- D03 CustomerProfile/CraftsmanProfile ownership.
- D26 identity security.

**Acceptance criteria**
- User entity exists with stable internal ID and account state.
- Customer/Craftsman roles are not modeled as mutually exclusive accounts.
- Suspended/deactivated states are representable without deleting history.
- No public profile exposure is introduced yet.

### R0-009 — Authentication/session baseline
Status: `READY`

**Objective**
Implement secure registration/login/logout/session and password-reset flows.

**Dependencies**
- R0-008, R0-003.

**Locked references**
- D02 verification requirements.
- D26 session/password/reset rules.
- D30 auth tests.

**Acceptance criteria**
- Registration/login/logout work.
- Password reset uses expiring one-time token.
- Session cookies use appropriate secure attributes for production.
- Logout invalidates session according to chosen auth architecture.
- Password/reset secrets never appear in logs.

**Negative tests**
- Reuse of reset token fails.
- Suspended account cannot regain forbidden capabilities through an old browser tab after authorization middleware is in place.

### R0-010 — Email verification
Status: `READY`

**Objective**
Implement one-time expiring email verification and resend rate limiting.

**Dependencies**
- R0-009, R0-021/R0-022 may be integrated before final delivery path; initial synchronous/test adapter is allowed only if it does not become domain authority.

**Locked references**
- D01/D02 email verification.
- D26 token/rate-limit rules.

**Acceptance criteria**
- Verification token is single-use and expiring.
- Resend is rate-limited.
- Verified state is server authoritative.
- Token values are redacted from logs.

### R0-011 — Phone verification
Status: `READY`

**Objective**
Implement OTP-based phone verification with provider abstraction and brute-force protection.

**Dependencies**
- R0-009.

**Locked references**
- D01/D02 phone verification.
- D26 OTP security.
- D27 purpose minimization.

**Acceptance criteria**
- OTP send/verify flows.
- Expiry, attempt limit and resend rate limit.
- Provider abstraction supports staging/test mode.
- Raw OTP never stored/logged unnecessarily.

### R0-012 — Admin identity, privileged roles and MFA
Status: `READY`

**Objective**
Create `ADMIN` / `SUPER_ADMIN` privileged access foundation with MFA.

**Dependencies**
- R0-009.

**Locked references**
- D23 admin levels/capabilities.
- D26 mandatory admin MFA and privileged-session hardening.
- D30 admin MFA launch gate.

**Acceptance criteria**
- Admin route is not a security boundary; backend privileged checks exist.
- ADMIN and SUPER_ADMIN are distinguishable.
- MFA required for privileged login/session.
- Normal ADMIN cannot self-promote to SUPER_ADMIN.
- Privileged role changes are auditable once R0-024 lands.

### R0-013 — Deny-by-default authorization framework
Status: `READY`

**Objective**
Create reusable server-side object/action authorization primitives before feature entities proliferate.

**Dependencies**
- R0-008.

**Locked references**
- D02 permissions.
- D23 admin capabilities.
- D26 object/field/action-level authorization.

**Acceptance criteria**
- Default deny for private resources.
- Policies receive actor + target/context + action.
- Public endpoints require explicit allowlisting.
- Authorization decisions live server-side.
- Framework supports future Job/Invitation/Conversation/Quote participant context.

**Negative tests**
- Unknown resource ID never grants access by ID knowledge alone.
- Missing policy defaults to forbidden.

### R0-014 — Field-level projection/privacy serializer
Status: `READY`

**Objective**
Ensure hidden fields are removed server-side rather than hidden only in UI.

**Dependencies**
- R0-013.

**Locked references**
- D02 contact/address boundaries.
- D07 location privacy.
- D26 field-level authorization.
- D27 public/private projections.

**Acceptance criteria**
- Response DTO/projection layer supports public/private/admin/contextual views.
- Private email/phone/exact address cannot accidentally appear in public projection.
- Admin internal notes/risk flags have no normal-user serializer path.

### R0-015 — Domain command/state guard primitives
Status: `READY`

**Objective**
Create the application pattern used later for explicit commands instead of generic status PATCHes.

**Dependencies**
- R0-006, R0-013.

**Locked references**
- D04 state machines.
- D16/D19/D20 transactional commands.
- D26 explicit command authorization/state guards.

**Acceptance criteria**
- Application command handler pattern supports actor authorization, current-state validation and DB transaction.
- No generic `setStatus(any)` foundation.
- Idempotency key hook available for critical commands.
- Domain-event/outbox hook available for successful commands.

### R0-016 — Object storage topology
Status: `READY`

**Objective**
Separate private assets from public portfolio derivatives at the storage architecture level.

**Dependencies**
- R0-003.

**Locked references**
- D13 central MediaAsset.
- D26 private/public storage and signed delivery.
- D27 media privacy.

**Acceptance criteria**
- Private bucket/container is not publicly listable/readable.
- Public derivative delivery path is separate and revocable.
- Server-generated object keys.
- No client filename used as storage path.

### R0-017 — MediaAsset model and controlled upload flow
Status: `READY`

**Objective**
Create the central media abstraction used by profiles, portfolio, chat, Job docs and credentials.

**Dependencies**
- R0-006, R0-016.

**Locked references**
- D03 MediaAsset.
- D09/D13 media provenance.
- D26 upload security.

**Acceptance criteria**
- MediaAsset records owner/uploader, type, status, timestamps, storage refs and provenance hooks.
- Uploads use server-authorized flow.
- File-size/type limits are enforceable centrally.
- Status supports at least PROCESSING/READY/REJECTED or equivalent.

### R0-018 — Image canonicalization pipeline
Status: `READY`

**Objective**
Safely decode ordinary uploaded images, strip unnecessary metadata and store optimized canonical derivatives.

**Dependencies**
- R0-017, R0-021.

**Locked references**
- D13 automatic image optimization.
- D26 image decode/re-encode, EXIF/GPS, pixel-bomb limits.

**Acceptance criteria**
- MIME/signature validation.
- Pixel/dimension/decompression-bomb limits.
- Orientation normalized into pixels.
- Allowed chronology metadata such as reliable captured_at can be extracted before metadata stripping.
- GPS EXIF is not public and is not retained by default without explicit use case.
- Canonical/thumbnail derivatives produced; oversized original is not canonical storage.

**Negative tests**
- Spoofed extension rejected.
- Decompression bomb rejected.
- Malformed image rejected without worker crash loop.

### R0-019 — PDF/document validation and malware-scan pipeline
Status: `READY`

**Objective**
Provide safe document ingestion for Quote PDFs, credentials, chat documents and Job evidence.

**Dependencies**
- R0-017, R0-021.

**Locked references**
- D13 docs/PDF.
- D14 immutable external Quote PDF.
- D26 allowlist/magic-byte/malware rules.

**Acceptance criteria**
- Allowlisted document types only.
- Real MIME/signature validation.
- File-size bounds.
- Malware scan/quarantine integration or provider abstraction.
- Unprocessed file is not exposed to counterpart as READY.
- Submitted commercial PDF can later be frozen as immutable asset/revision.

### R0-020 — Private file authorization and signed delivery
Status: `READY`

**Objective**
Guarantee private files are downloadable only after server authorization.

**Dependencies**
- R0-013, R0-016, R0-017.

**Locked references**
- D26 private asset delivery.
- D30 private-file IDOR gate.

**Acceptance criteria**
- Download endpoint checks actor/context before issuing file.
- Signed URLs are short-lived.
- Storage keys are non-enumerable and not authorization credentials.
- Public portfolio derivative path can be revoked on hide/moderation.

**Negative tests**
- User A changing MediaAsset ID cannot fetch User B private asset.
- Expired signed URL fails.

### R0-021 — Background worker/queue foundation
Status: `READY`

**Objective**
Create async job processing used by media, notifications, analytics and maintenance tasks.

**Dependencies**
- R0-003.

**Locked references**
- D25 async delivery.
- D26/D29 queue reliability/monitoring.

**Acceptance criteria**
- Queue abstraction with retries/backoff and terminal failure handling.
- Job/run IDs and correlation context.
- Worker can be deployed independently.
- Retry exhaustion is observable.

### R0-022 — Transactional outbox/domain-event delivery
Status: `READY`

**Objective**
Prevent business commits from losing follow-up events between DB transaction and async delivery.

**Dependencies**
- R0-006, R0-015, R0-021.

**Locked references**
- D25 transactional outbox principle.
- D28 server-side event capture.
- D29 outbox monitoring.

**Acceptance criteria**
- Domain command can persist business state + outbox event atomically.
- Worker publishes/processes event idempotently.
- Duplicate worker delivery does not duplicate consumer effect when consumer uses event key.
- Outbox backlog/age is observable.

### R0-023 — Notification foundation
Status: `READY`

**Objective**
Implement notification records and channel abstraction without feature-specific notification catalog yet.

**Dependencies**
- R0-022.

**Locked references**
- D25 complete notification model.

**Acceptance criteria**
- Notification has stable type, recipient, context/entity, created/read state, priority and idempotency/event key.
- In-app storage works.
- Email adapter interface exists with retry-safe delivery state.
- Read/open does not mutate business state.
- Sensitive payload is minimized.

### R0-024 — Immutable admin/security audit log foundation
Status: `READY`

**Objective**
Create append-oriented audit records for privileged and sensitive operations.

**Dependencies**
- R0-006, R0-012.

**Locked references**
- D23 audit requirements.
- D26 privileged access audit.
- D27 retention/minimization boundary.

**Acceptance criteria**
- Actor, action type, target type/id, server timestamp and reason where required.
- Safe before/after diff support without indiscriminate sensitive-value copying.
- No ordinary admin edit/delete UI/API for audit records.
- Supports recording sensitive-access events.

### R0-025 — Admin console shell
Status: `READY`

**Objective**
Create a secure internal UI shell that later receives approval/dispute/moderation queues.

**Dependencies**
- R0-012, R0-013, R0-024.

**Locked references**
- D23 admin console.

**Acceptance criteria**
- Privileged navigation shell.
- Capability-gated routes/actions.
- No generic DB editor.
- No user impersonation.
- Placeholder queue/dashboard framework supports future profile/credential/dispute/report modules.

### R0-026 — Structured logging + error tracking
Status: `READY`

**Objective**
Make dev/staging/prod failures diagnosable without leaking private payloads.

**Dependencies**
- R0-003, R0-005.

**Locked references**
- D26 logging minimization.
- D29 structured logs/error tracking.

**Acceptance criteria**
- Structured JSON logs with request/correlation ID, environment, service, release.
- Central error tracker for frontend/backend/worker.
- PII/token redaction baseline.
- Production stack traces not returned to users.
- Deploy/release context attached to errors.

### R0-027 — Metrics, health checks and actionable alerts
Status: `READY`

**Objective**
Implement alpha system-health visibility.

**Dependencies**
- R0-005, R0-006, R0-021, R0-026.

**Locked references**
- D29 health/metrics/alerting.
- D30 observability release gates.

**Acceptance criteria**
- Liveness/readiness endpoints.
- HTTP count/error/latency metrics.
- DB/queue worker baseline metrics.
- At least one critical alert channel configured for staging test.
- High-cardinality user/job IDs excluded from metric labels.

### R0-028 — Backup, restore and recovery baseline
Status: `READY`

**Objective**
Make DB/media recovery real rather than assumed.

**Dependencies**
- R0-006, R0-016.

**Locked references**
- D26 backups.
- D27 backup retention/deletion-state considerations.
- D29/D30 restore monitoring/gates.

**Acceptance criteria**
- Automatic DB backups enabled in staging/production plan.
- Media recovery/backup policy documented according to chosen storage provider.
- Restore runbook exists.
- One staging restore test can be executed and recorded before real-user alpha.
- Deletion/anonymization tombstone/reapplication requirement documented for later D27 workflow implementation.

### R0-029 — Product analytics abstraction + event envelope
Status: `READY`

**Objective**
Create a privacy-minimized analytics interface without coupling domain code to one vendor.

**Dependencies**
- R0-022.

**Locked references**
- D28 event schema/vendor boundary.
- D27 analytics privacy.

**Acceptance criteria**
- Stable event envelope supports event_id/name/time, actor/anonymous context, platform/environment/schema version.
- Domain code calls internal analytics abstraction, not vendor SDK directly.
- Payload allowlist prevents dumping business objects.
- Staging/dev separated from production.

### R0-030 — Privacy/compliance scaffolding
Status: `READY`

**Objective**
Prepare technical primitives needed by D27 before feature data spreads across the system.

**Dependencies**
- R0-006, R0-008, R0-024.

**Locked references**
- D27 full privacy architecture.

**Acceptance criteria**
- Policy/version record primitive.
- Consent-purpose record primitive for genuinely optional consents.
- Retention policy configuration mechanism (values may be filled by launch/legal work later).
- Privacy-request case model skeleton.
- Account deactivation/closure state can be represented without cascade deletion.
- Public/private classification conventions documented for feature teams.

### R0-031 — Seed data and test factories
Status: `READY`

**Objective**
Provide deterministic users/roles/locations/taxonomy placeholders needed for integration/E2E development.

**Dependencies**
- R0-006, R0-008.

**Locked references**
- D30 seed/test-data requirements.

**Acceptance criteria**
- Factory/seed support for customer, craftsman, combined user, admin/superadmin, suspended user.
- Slovak location seed mechanism prepared.
- Profession taxonomy seed mechanism prepared (content itself continues in R1).
- Test data is clearly non-production and excluded/taggable for analytics.

### R0-032 — Authorization/integration/E2E test harness
Status: `READY`

**Objective**
Create the automated test infrastructure required for negative permission and transactional tests in R1–R4.

**Dependencies**
- R0-009, R0-013, R0-015, R0-020, R0-031.

**Locked references**
- D26 security testing.
- D30 release gates.

**Acceptance criteria**
- Isolated integration DB per test run or equivalent clean-state mechanism.
- Authenticated request helpers for multiple users/roles.
- Negative authorization test helpers.
- File-access IDOR test fixture.
- Concurrency/idempotency test helper for future Quote acceptance/Change-order/completion tests.

### R0-033 — Release pipeline, smoke check and rollback baseline
Status: `READY`

**Objective**
Turn CI/staging/observability into a controlled release process.

**Dependencies**
- R0-004, R0-005, R0-027, R0-028, R0-032.

**Locked references**
- D30 release process/go-no-go.

**Acceptance criteria**
- Release candidate can deploy to staging.
- Automated smoke verifies public app + auth entrypoint + DB readiness.
- Production deploy is protected by explicit go/no-go step.
- Release revision visible in monitoring.
- Rollback/forward-fix procedure documented.

---

# R1 — Supply side

## R1 dependency
Starts after the R0 database/auth/authorization/media/test foundations needed by each ticket are DONE. Not every R0 ticket must block every R1 ticket, but R1 must not bypass R0 primitives.

## R1 epics / ticket queue
- `R1-001` Canonical Profession/Specialization taxonomy + seed governance — D06.
- `R1-002` CustomerProfile lazy creation foundation — D02/D03.
- `R1-003` CraftsmanProfile core entity INDIVIDUAL/COMPANY — D02/D03/D08.
- `R1-004` Craftsman profession/proficiency relationships — D06/D08.
- `R1-005` Skills/specializations and declared-vs-evidence presentation primitives — D06/D08.
- `R1-006` Base location + service radius + extra service areas — D07/D08.
- `R1-007` Indicative pricing entries — D08.
- `R1-008` Experience/working-since data — D08.
- `R1-009` Credential claim + evidence + admin approval queue — D08/D23/D24.
- `R1-010` Profile approval/publish/hide/moderation visibility state — D02/D08/D23/D24.
- `R1-011` Public CraftsmanProfile projection/page — D08/D26/D27.
- `R1-012` Availability calendar alpha — D08.
- `R1-013` PortfolioProject core/self-declared provenance — D09.
- `R1-014` Portfolio media/photos/phase tags/max-15 — D09/D13/D26.
- `R1-015` Job-linked portfolio provenance hooks — D09 (completed in R4 integration).
- `R1-016` Portfolio collaborators/role/contribution model — D09.
- `R1-017` Featured projects max-3 — D09.
- `R1-018` Property-photo consent/publication hooks — D09/D20/D27 (full flow finalized in R4).
- `R1-019` R1 authorization/privacy/E2E suite — D26/D30.

## R1 exit condition
An approved PUBLIC craftsman can expose the locked public profile, profession/service-area/availability/portfolio information without leaking private contact/home-address/credential evidence; admin can approve profiles/credentials and R1 negative permission tests pass.

---

# R2 — Discovery

## R2 epics / ticket queue
- `R2-001` Search index/query model over approved PUBLIC craftsmen — D10.
- `R2-002` Profession/service query + taxonomy autocomplete — D10.
- `R2-003` Location/PostGIS distance query — D07/D10.
- `R2-004` Service-radius/outside-radius matching semantics — D07/D10.
- `R2-005` Specialization/skill relevance incl. evidence-aware signal hooks — D10.
- `R2-006` Required credential qualification gating — D10/D12.
- `R2-007` Availability soft signal/filter — D08/D10.
- `R2-008` Trust/evidence aggregation read model — D05/D10 (initially sparse/cold-start-safe).
- `R2-009` Recommended ranking pipeline with non-paid organic invariants — D10.
- `R2-010` Nearest/Best-rated sort modes — D10.
- `R2-011` Search cards + why-matched explanations — D10.
- `R2-012` Shortlist persistence/UI — D10/D12.
- `R2-013` Search analytics events/liquidity instrumentation — D28.
- `R2-014` Search privacy/security/performance tests — D26/D29/D30.

## R2 exit condition
Public discovery can find qualified craftsmen by profession/location with privacy-safe geo output, cold-start-safe ranking, no paid/founder organic boost, and a reusable shortlist feeding R3 invitations.

---

# R3 — Demand side

## R3 epics / ticket queue
- `R3-001` JobRequest DRAFT/ACTIVE entity + state machine — D03/D04/D11.
- `R3-002` Server autosave + draft recovery — D01/D11.
- `R3-003` Auth-boundary draft survival — D01/D30 critical invariant.
- `R3-004` JobRequest form/validation/photos/location/timing/budget — D11.
- `R3-005` JobRequest versioning/material edits — D04/D11/D12.
- `R3-006` Active-request limits/expiry/reactivate/duplicate — D11.
- `R3-007` JobInvitation entity/lifecycle/max-5 active — D03/D04/D12.
- `R3-008` Candidate list → customer-selected invitations — D12.
- `R3-009` Invitation notifications/reminders — D25.
- `R3-010` Invitation ENGAGED/DECLINED/EXPIRED/WITHDRAWN/NOT_SELECTED UX — D12.
- `R3-011` Conversation entity + ENGAGED gate — D03/D13.
- `R3-012` Chat messages/read receipts/unread/archive/mute/report — D13.
- `R3-013` Chat photo/document attachments + Job-doc hooks — D13.
- `R3-014` Pre-confirm contact/address protection in chat — D02/D13/D26.
- `R3-015` Quote core/revisions/state machine — D14.
- `R3-016` PLATFORM_STRUCTURED Quote authoring — D14.
- `R3-017` EXTERNAL_PDF Quote authoring + immutable revisions — D14.
- `R3-018` Quote comparison normalization/UI — D15.
- `R3-019` Quote expiry/withdraw/stale handling — D14/D15/D16.
- `R3-020` Demand-side notification catalog — D25.
- `R3-021` R3 analytics funnel events — D28.
- `R3-022` Competitor isolation/IDOR/E2E suite — D26/D30.

## R3 exit condition
A verified customer can create/recover/version a request, invite a bounded shortlist, privately engage craftsmen, chat and receive comparable structured/PDF quotes while competitors remain isolated and pre-confirm private contacts/address stay protected.

---

# R4 — Transaction + Web Alpha hardening

## R4 epics / ticket queue
- `R4-001` Final Quote acceptance recap — D16.
- `R4-002` Race-safe/idempotent acceptQuote transaction + one primary Job invariant — D04/D16/D26.
- `R4-003` Immutable Job/request/Quote/PDF snapshot + competitor closeout — D16.
- `R4-004` Post-confirm contact/address unlock — D02/D07/D16/D26.
- `R4-005` Job dashboard/timeline/read model — D17.
- `R4-006` CONFIRMED→IN_PROGRESS + cancellation workflow — D04/D17.
- `R4-007` Job documentation/photos/docs + provenance — D13/D17.
- `R4-008` JobParticipant/Crew/JobWorkGroup minimal alpha — D03/D17.
- `R4-009` Participant invitation/join/leave/history/evidence — D17.
- `R4-010` Progress updates + Issues — D17.
- `R4-011` Milestones — D18.
- `R4-012` ChangeOrder entity/revisions/propose/approve/reject/withdraw — D19.
- `R4-013` Current commercial state derivation base + approved changes — D19.
- `R4-014` Completion request/accept/reject/retry/history — D20.
- `R4-015` Customer-proposed completion path/admin force-complete distinction — D20/D23.
- `R4-016` Verified participation/completed-job evidence generation — D05/D17/D20.
- `R4-017` Main bilateral sealed reviews — D05/D21.
- `R4-018` Participant/workgroup reviews — D05/D21.
- `R4-019` Supervisor evaluations — D05/D21.
- `R4-020` Review response/report/moderation integration — D21/D24.
- `R4-021` Dispute case model/workflow/evidence — D22.
- `R4-022` Admin dispute/exceptional Job operations — D22/D23.
- `R4-023` Moderation report/action/appeal workflows — D24.
- `R4-024` Full alpha notification catalog + preferences — D25.
- `R4-025` Final permission matrix hardening across all R1–R4 entities — D26.
- `R4-026` GDPR operational workflows: privacy requests/account closure/deindex/photo consent/retention jobs — D27.
- `R4-027` Alpha analytics event catalog + core dashboards — D28.
- `R4-028` Alpha observability dashboards/invariant monitors/runbooks — D29.
- `R4-029` Backup restore rehearsal + operational checklist — D29/D30.
- `R4-030` Canonical full-loop staging E2E — D30.
- `R4-031` Security negative/race/upload/sealed-review launch suite — D26/D30.
- `R4-032` Manual UAT scripts + go/no-go checklist — D30.
- `R4-033` Production invite-only rollout controls + smoke/rollback — D30.

## R4 / WEB ALPHA exit condition
All D30 hard gates pass. A real invited customer and craftsman can complete the full marketplace loop without manual DB intervention; critical authorization/privacy/race invariants pass; backups/restore, observability, notifications, admin operations and privacy minimums are production-ready.

---

# Cross-release sequencing

## R0 → R1
R1 may begin incrementally once database/auth/authorization/media/test primitives required by its first tickets are DONE; do not wait for unrelated R0 polish if dependencies are already satisfied.

## R1 → R2
R2 requires approved/public profile projections, profession taxonomy, service area and at least basic trust/evidence read-model hooks.

## R2 → R3
R3 invitation candidate discovery depends on R2 search/matching and R1 public profiles, but JobRequest core can begin earlier after R0.

## R3 → R4
R4 Quote acceptance requires stable JobRequest/Invitation/Conversation/Quote models. Job lifecycle, change orders, completion and reviews must build on immutable acceptance snapshots rather than patching earlier entities ad hoc.

# Current execution checkpoint
Definition: `D01–D30 LOCKED`.
Backlog artifact: `CREATED`.
Active release: `R0 — Foundation`.
Active ticket: `R0-001 — Bootstrap TypeScript monorepo`.
Next after R0-001: `R0-002` + `R0-003` can proceed in parallel, then `R0-004/R0-006`.
